package com.csc_340.skysave_mywork.controllers;

import com.csc_340.skysave_mywork.models.Subscription;
import com.csc_340.skysave_mywork.models.User;
import com.csc_340.skysave_mywork.services.CustomerService;
import com.csc_340.skysave_mywork.services.SubscriptionRepository;
import com.csc_340.skysave_mywork.services.SubscriptionService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class SubscriptionController {

    @Autowired
    private SubscriptionRepository subscriptionRepository;

    @Autowired
    private CustomerService customerService;

    @Autowired
    private SubscriptionService subscriptionService;

    @GetMapping("/subscriptions")
    public String showProfile(Model model, HttpSession session) {
        User loggedInUser = (User) session.getAttribute("loggedInUser");
        if (loggedInUser == null) {
            return "redirect:/login";
        }

        User user = customerService.getCustomerByUsername(loggedInUser.getUsername());
        List<Subscription> subscriptions = subscriptionService.findByUsername(loggedInUser.getUsername());
        model.addAttribute("subscriptions", subscriptions);
        model.addAttribute("user", loggedInUser);
        return "profile";
    }

    @PostMapping("/subscribe")
    public String subscribeToProvider(@RequestParam String provider, HttpSession session) {
        User loggedInUser = (User) session.getAttribute("loggedInUser");
        if (loggedInUser == null) {
            return "redirect:/login";
        }

        String username = loggedInUser.getUsername();
        Subscription subscription = new Subscription();
        subscription.setUsername(username);
        subscription.setProvider(provider);

        subscriptionService.subscribe(subscription);
        return "redirect:/profile";
    }
}
