package com.csc_340.skysave_mywork.controllers;

import com.csc_340.skysave_mywork.models.Review;
import com.csc_340.skysave_mywork.models.User;
import com.csc_340.skysave_mywork.services.CustomerService;
import com.csc_340.skysave_mywork.services.ReviewRepository;
import com.csc_340.skysave_mywork.services.ReviewService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class ReviewController {


    @Autowired
    private ReviewService reviewService;

    @GetMapping("/write-review")
    public String showReviewForm(@RequestParam("provider") String provider, Model model, HttpSession session) {
        if (session.getAttribute("loggedInUser") == null) {
            return "redirect:/login";
        }
        Review review = new Review();
        review.setProvider(provider); // Set the provider
        model.addAttribute("review", review);
        return "writeReview";
    }

    @PostMapping("/write-review")
    public String submitReview(@ModelAttribute Review review, HttpSession session ) {
        if (session.getAttribute("loggedInUser") == null) {
            return "redirect:/login";
        }
        // Save the review to the repository
        reviewService.saveReview(review);

        System.out.println("Review submitted: " + review);

        // Redirect to the search results or some other page
        return "redirect:/searchResults";
    }
}
