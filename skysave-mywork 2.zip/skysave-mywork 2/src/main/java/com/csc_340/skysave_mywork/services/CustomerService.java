package com.csc_340.skysave_mywork.services;

import com.csc_340.skysave_mywork.models.User;

public interface CustomerService {

    //Profile Management
    User createCustomer(User user);
    User getCustomerByUsername(String username);
    void updateCustomer(User user);


}
