package com.csc_340.skysave_mywork.services;

import com.csc_340.skysave_mywork.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;


@Service

public class CustomerServiceImpl implements CustomerService {

    private static final Logger logger = LoggerFactory.getLogger(CustomerService.class);

    public CustomerServiceImpl(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }



    @Autowired
    private CustomerRepository customerRepository;


    @Override
    public User createCustomer(User user) {
        if (customerRepository.existsByUsername(user.getUsername())) {
            throw new IllegalArgumentException("Username already exists: " + user.getUsername());
        }
        return customerRepository.save(user);
    }

    @Override
    public User getCustomerByUsername(String username) {

        return customerRepository.findByUsername(username);
    }

    @Override
    public void updateCustomer(User user) {

        // Validate and encode the password if it is being updated

        customerRepository.save(user);

    }








}
