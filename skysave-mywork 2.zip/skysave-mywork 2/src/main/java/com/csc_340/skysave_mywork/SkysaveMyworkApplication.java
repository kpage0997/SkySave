package com.csc_340.skysave_mywork;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkysaveMyworkApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkysaveMyworkApplication.class, args);
	}

}
