package com.csc_340.skysave_mywork.models;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import lombok.Data;
import org.springframework.data.annotation.Id;

@Entity
@Data
public class Subscription {
    @jakarta.persistence.Id
    @Id

    private Long id;

    @Column(nullable = false)
    private String username;

    @Column(nullable = false)
    private String provider;

}
