package com.csc_340.skysave_mywork.controllers;

import com.csc_340.skysave_mywork.models.User;
import jakarta.servlet.http.HttpSession;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

@ControllerAdvice
public class GlobalControllerAdvice {

    @ModelAttribute("loggedInUser")
    public User addUserToModel(HttpSession session) {
        return (User) session.getAttribute("loggedInUser");
    }
}
