package com.csc_340.skysave_mywork.services;

import com.csc_340.skysave_mywork.models.Subscription;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SubscriptionService {
    @Autowired
    private SubscriptionRepository subscriptionRepository;

    public void subscribe(Subscription subscription) {
        subscriptionRepository.save(subscription);
    }

    public List<Subscription> findByUsername(String username) {
        return subscriptionRepository.findByUsername(username);
    }
}
