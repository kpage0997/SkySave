package com.csc_340.skysave_mywork.controllers;

import com.csc_340.skysave_mywork.models.User;
import com.csc_340.skysave_mywork.services.CustomerService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class UserController {

    private final HttpSession httpSession;
    private CustomerService customerService;


    public UserController(CustomerService customerService, HttpSession httpSession) {
        this.customerService = customerService;
        this.httpSession = httpSession;
    }

    @GetMapping("/home")
    public String homePage(Model model) {
        // You can add attributes to the model here if needed
        // model.addAttribute("attributeName", attributeValue);
        return "home";
    }

    @GetMapping("/searchResults")
    public String showResultsPage(){

        return "searchResults";
    }

    @GetMapping("/contact")
    public String showContactPage() {
        return "contact";
    }


    @GetMapping("/create")
    public String showCreateUserForm(Model model) {
        model.addAttribute("user", new User());
        return "registerForm";
    }

    @PostMapping("/register")
    public String registerCustomer(@ModelAttribute User user, Model model) {
        try {
            user.setRole("customer"); // Set default role
            customerService.createCustomer(user);
            model.addAttribute("user", new User());
            model.addAttribute("message", "Account created successfully! Please sign in.");
            return "redirect:/login";
        } catch (IllegalArgumentException e) {
            model.addAttribute("error", e.getMessage());
            return "registerForm";
        }
    }

    @GetMapping("/login")
    public String showLoginForm(Model model) {
        return "login";
    }

    @PostMapping("/login")
    public String processLogin(@RequestParam String username, @RequestParam String password, Model model, HttpSession session) {

        try {
            User user = customerService.getCustomerByUsername(username);
            if (user == null) {
                model.addAttribute("error", "Username does not exist.");
                return "login";
            }

            if (!user.getPassword().equals(password)) {
                model.addAttribute("error", "Invalid password.");
                return "login";
            }
            session.setAttribute("loggedInUser", user);
            return "redirect:/home";
        } catch (Exception e) {
            model.addAttribute("error", "An unexpected error occurred. Please try again.");
            return "login";
        }

    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/home";
    }

    @GetMapping("/profile")
    public String showProfile(Model model, HttpSession session) {
        User loggedInUser = (User) session.getAttribute("loggedInUser");
        if (loggedInUser == null) {
            return "redirect:/login";
        }
        User user = customerService.getCustomerByUsername(loggedInUser.getUsername());
        model.addAttribute("user", user);
        return "profile";
    }

    @PostMapping("/profile")
    public String updateProfile(@RequestParam String displayName, @RequestParam String password, HttpSession session, Model model) {
        User loggedInUser = (User) session.getAttribute("loggedInUser");
        if (loggedInUser == null) {
            return "redirect:/login";
        }
        User user = customerService.getCustomerByUsername(loggedInUser.getUsername());
        if (user != null) {
            user.setDisplayName(displayName);
            user.setPassword(password);
            customerService.updateCustomer(user);
            session.setAttribute("loggedInUser", user); // Update session with the new user details
            model.addAttribute("success", "Profile updated successfully.");
        } else {
            model.addAttribute("error", "User not found.");
        }
        model.addAttribute("user", user);
        return "profile";
    }








}









