package com.csc_340.skysave_mywork.services;

import com.csc_340.skysave_mywork.models.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomerRepository extends JpaRepository<User, String> {
    User findByUsername(String username);
    boolean existsByUsername(String username);

    //Create Operations

    //1.S save(S entity): saves a given entity and returns the saved entity
    //2.S saveAndFlush(S entity): saves an entity and flushes changes

    //Read Operations

    //1. Optional<T> findById(ID id): Retrieves an entity by its ID.
    //2. boolean existsById(ID id): Checks whether an entity with the given ID exists.
    //3. List<T> findAll(): Retrieves all entities.
    //4. List<T> findAllById(Iterable<ID> ids): Retrieves all entities with the given IDs.
    //5. long count(): Counts the number of entities.

    //Update Operations

    //1. S save(S entity): Saves a given entity. It returns the saved entity.
    //2. S saveAndFlush(S entity): Saves an entity and flushes changes instantly.

    //Delete Operations

    //1. void deleteById(ID id): Deletes the entity with the given ID.
    //2. void delete(T entity): Deletes a given entity.
    //3. void deleteAll(Iterable<? extends T> entities): Deletes the given entities.
    //4. void deleteAll(): Deletes all entities.

}
