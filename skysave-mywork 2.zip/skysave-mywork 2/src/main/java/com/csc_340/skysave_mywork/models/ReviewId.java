package com.csc_340.skysave_mywork.models;

import java.io.Serializable;
import java.util.Objects;

public class ReviewId implements Serializable {
    private String username;
    private String provider;

    public ReviewId() {}

    public ReviewId(String username, String provider) {
        this.username = username;
        this.provider = provider;
    }

    // Getters, setters, equals, and hashCode methods

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ReviewId reviewId = (ReviewId) o;
        return Objects.equals(username, reviewId.username) &&
                Objects.equals(provider, reviewId.provider);
    }

    @Override
    public int hashCode() {
        return Objects.hash(username, provider);
    }

}
