package com.csc_340.skysave_mywork.models;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.IdClass;
import lombok.Data;

import java.io.Serializable;

@Entity
@IdClass(ReviewId.class)
@Data
public class Review implements Serializable {

    @Id
    private String username; // User who wrote the review

    private String provider; // Provider being reviewed

    private String comment; // Review content
    private Integer rating; // Rating out of 5


}


