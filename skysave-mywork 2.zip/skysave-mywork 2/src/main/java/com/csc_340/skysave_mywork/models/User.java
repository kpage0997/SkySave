package com.csc_340.skysave_mywork.models;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Generated;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;


@Entity
@NoArgsConstructor
@Data
@AllArgsConstructor
public class User {

    @Id
   @Column(nullable = false, unique = true) // Ensures the username is unique and not null.
    private String username;


    @Column(nullable = false) // Ensures the password is not null.
    private String password;

    @Column(nullable = false) // Ensures the role is not null.
    private String role = "customer";

    @Column(nullable = false) // Ensures the display name is not null.
    private String displayName;



    @ElementCollection
    private List<String> subscriptions = new ArrayList<>();



    public User(String username, String displayName, String role, String password) {
        this.username = username;
        this.displayName = displayName;
        this.role = role;
        this.password = password;
    }



}
