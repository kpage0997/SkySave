package com.csc_340.skysave_mywork.security;

import com.csc_340.skysave_mywork.services.MyUserDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.csrf.CookieCsrfTokenRepository;

import static org.springframework.security.config.Customizer.withDefaults;

@Configuration
@EnableWebSecurity
public class SecurityConfig {


    public SecurityConfig() {
        this(null);
    }

    public SecurityConfig(MyUserDetailService userDetailsService) {
        this.userDetailsService = userDetailsService;
    }

    private final MyUserDetailService userDetailsService;

    @Bean
    public PasswordEncoder passwordEncoder() {
        return NoOpPasswordEncoder.getInstance(); // Using NoOpPasswordEncoder to store passwords as plain text
    }


    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

       http
               .csrf(csrf -> csrf.csrfTokenRepository(CookieCsrfTokenRepository.withHttpOnlyFalse()))
               .authorizeHttpRequests(authorize -> authorize
                       .requestMatchers("/home", "/login", "/register", "/create", "/contact", "/logout",
                               "/profile", "/searchResults", "/subscribe", "/write-review", "/subscriptions").permitAll() // Allow access to these endpoints without authentication
                       //.requestMatchers( "/subscriptions").authenticated() // Require authentication for any other request
                       .anyRequest().authenticated()

               )
               .formLogin(formLogin -> formLogin
                       .loginPage("/login").permitAll() // Specify custom login page
                       .defaultSuccessUrl("/home", true) // Redirect to home page on successful login
                       .failureUrl("/errorPage") // Redirect to login page on failure
                       .loginProcessingUrl("/perform_login") // URL to submit the username and password
                       .usernameParameter("username") // Parameter name for username
                       .passwordParameter("password") // Parameter name for password
               );
               http.logout(logout -> logout
                       .logoutUrl("/logout")
                       .logoutSuccessUrl("/logout")
                       .permitAll()
        );




        return http.build();
    }

@Bean
public AuthenticationManager authenticationManager(
        AuthenticationConfiguration authenticationConfiguration) throws Exception {
        return authenticationConfiguration.getAuthenticationManager();
}




}
