package com.csc_340.skysave_mywork.services;

import com.csc_340.skysave_mywork.models.User;
import com.csc_340.skysave_mywork.models.UserPrincipal;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class MyUserDetailService implements UserDetailsService {
    private static final Logger logger = LoggerFactory.getLogger(MyUserDetailService.class);

    private final CustomerRepository customerRepository;

    public MyUserDetailService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

        User user = customerRepository.findByUsername(username);
        if (user == null) {

            throw new UsernameNotFoundException("User 404");
        }

        logger.info("User found: {}", username);
        return org.springframework.security.core.userdetails.User.withUsername(user.getUsername())
                .password(user.getPassword())
                .authorities("USER") // Set authorities/roles as needed
                .accountExpired(false) // Change to false
                .accountLocked(false) // Change to false
                .credentialsExpired(false) // Change to false
                .disabled(false) // Change to false
                .build();
        //return new UserPrincipal(user);
    }
}
