package com.csc_340.skysave_mywork;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkysaveMyworkApplicationTests {

	@Test
	void contextLoads() {
	}

}
